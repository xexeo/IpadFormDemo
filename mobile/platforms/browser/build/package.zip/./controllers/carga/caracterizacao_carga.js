/* global util, registro */

controllers.caracterizacao_carga = {
    config : function(){
        var me = controllers.caracterizacao_carga;
		me.inicializaElementos();
		me.progressoTela();
        me.buttons();
    },
    
    buttons : function(){
      //TODO
    },
    
	//Inicializa os elementos da tela
    inicializaElementos : function(){
    	//TODO
	},

	
	//Controla o show e hide dos elementos da tela
	progressoTela : function() {
		//TODO
    },
    
	// Controla as validações dos componentes de tela após clicar em AVANÇAR
	validar_componentes : function(id_avancar) {
		//TODO
	}
    
};

